@extends('layouts.master')
@section('title')
    @lang('translation.analytics')
@endsection
@section('css')
@endsection
@section('content')
    @component('components.breadcrumb')
        @slot('li_1')
            Dashboards
        @endslot
        @slot('title')
        {{ __("translation.edit_media") }}
        @endslot
    @endcomponent


    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">



            </div>
            <div class="card-body">
              <form id="geniusform" action="{{route('admin-media-update',$data->id)}}" method="POST" enctype="multipart/form-data">
                {{csrf_field()}}
                @include('includes.admin.form-both')


 
                        <div class="row">


                            <div class="col-xl-12 col-md-12">
                                <div class="mb-3">
                                    <label for="youtube_url" class="form-label">{{ __('translation.youtube_url') }}</label>
                                    <input type="text" class="form-control" name="youtube_url" value="{{ $data->youtube_url }}" id="youtube_url" placeholder="{{ __('translation.youtube_url') }}">
                                </div>
                                 
                            </div> <!-- end col -->


                            <div class="col-xl-12 col-md-12 d-none">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title mb-0"> {{ __('translation.media') }}</h4>
                                    </div><!-- end card header -->

                                    <div class="card-body">
                                        <p class="text-muted">FilePond is a JavaScript library with profile picture-shaped
                                            file
                                            upload variation.</p>
                                        <div class="currrent-logo" style="text-align: center;">
                                             @if($data->type == 'photo')   
                                            <img style="width: 171px;" src="{{$data->media ? $data->media  :  asset('assets/images/noimage.png') }}"
                                                alt="">
                                            @else
                                            <video width="640" height="360" controls>
                                                <source src="{{$data->media}}" type="video/{{$data->ext}}">
                                                <source src="video.ogg" type="video/ogg">
                                                Your browser does not support the video tag.
                                           </video>
                                            @endif

                                        </div>
                                        <div class="avatar-xl mx-auto">
                                            <input type="file" class="filepond filepond-input-circle" name="media"
                                                  />
                                        </div>


                                    </div>
                                    <!-- end card body -->


                                </div>
                                <!-- end card -->
                            </div> <!-- end col -->


                            <div class="col-xl-12 col-md-12  d-none">
                                <div class="mb-3">
                                    <label for="youtube_url" class="form-label">{{ __('translation.youtube_url') }}</label>
                                    <input type="text" class="form-control" name="youtube_url" id="youtube_url" value="{{$data->youtube_url}}" placeholder="{{ __('translation.youtube_url') }}">
                                </div>
                                 
                            </div> <!-- end col -->


                        </div>



                        <br>
                        <br>
                        <br>
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="left-area">

                                </div>
                            </div>
                            <div class="col-lg-7">
                                <button class="addProductSubmit-btn btn btn-secondary"
                                    type="submit">{{ __('translation.save') }}</button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
@endsection
