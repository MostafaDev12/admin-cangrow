<!-- ========== App Menu ========== -->
<div class="app-menu navbar-menu">
    <!-- LOGO -->
    <div class="navbar-brand-box">
        <!-- Dark Logo-->
        <a href="{{ route('admin.dashboard') }}" class="logo logo-dark">
            <span class="logo-sm">
                <img src="{{ URL::asset('build/images/logo-sm.png') }}" alt="" height="22">
            </span>
            <span class="logo-lg">
                <img src="{{ $gs->logo_en }}" alt="" height="60">
            </span>
        </a>

        {{-- {{ URL::asset('build/images/cangrow.png') }} --}}
        <!-- Light Logo-->
        <a href="{{ route('admin.dashboard') }}" class="logo logo-light">
            <span class="logo-sm">
                <img src="{{ URL::asset('build/images/logo-sm.png') }}" alt="" height="22">
            </span>
            <span class="logo-lg">
                <img src="{{ $gs->logo_en }}" alt="" height="60">
            </span>
        </a>
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
            id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">

            <div id="two-column-menu">
            </div>
            <ul class="navbar-nav" id="navbar-nav">
                <li class="menu-title"><span>@lang('translation.menu')</span></li>
                <li class="nav-item">
                    <a class="nav-link  " href="{{ route('admin.dashboard') }}" aria-controls="sidebarDashboards">
                        <i class="las la-tachometer-alt"></i> <span>@lang('translation.dashboards')</span>
                    </a>
                </li> <!-- end Dashboard Menu -->

                <li class="menu-title"><i class="ri-more-fill"></i> <span>@lang('translation.pages')</span></li>

                {{-- 
                @if (Auth::guard('admin')->user()->sectionCheck('slider'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-slider-index') }}" aria-controls="sidebarsliders">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.sliders')</span>
                        </a>
                    </li>
                @endif --}}



                <li class="nav-item">
                    <a class="nav-link menu-link" href="#models" data-bs-toggle="collapse" role="button"
                        aria-expanded="false" aria-controls="models">
                        <i class="las la-cog"></i> <span data-key="t-General_Settings"> @lang('translation.home')</span>
                    </a>
                    <div class="collapse menu-dropdown" id="models">
                        <ul class="nav nav-sm flex-column">

                            @if (Auth::guard('admin')->user()->sectionCheck('timelines'))
                                <li class="nav-item">
                                    <a class="nav-link  " href="{{ route('admin-timelines-index') }}"
                                        aria-controls="sidebarblogs">
                                        <i class="las la-tachometer-alt"></i> <span>@lang('translation.timelines')</span>
                                    </a>
                                </li>
                            @endif
                            @if (Auth::guard('admin')->user()->sectionCheck('certificates'))
                                <li class="nav-item">
                                    <a class="nav-link  " href="{{ route('admin-certificates-index') }}"
                                        aria-controls="sidebarblogs">
                                        <i class="las la-tachometer-alt"></i> <span>@lang('translation.smile_gallery')</span>
                                    </a>
                                </li>
                            @endif

                            @if (Auth::guard('admin')->user()->sectionCheck('page_settings'))
                                <li class="nav-item">
                                    <a class="nav-link  " href="{{ route('admin-ps-about_us') }}"
                                        aria-controls="sidebarabout_us">
                                        <i class="las la-tachometer-alt"></i> <span>@lang('translation.about_us')</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link  " href="{{ route('admin-ps-portfolio') }}"
                                        aria-controls="sidebarportfolio">
                                        <i class="las la-tachometer-alt"></i> <span>@lang('translation.portfolio')</span>
                                    </a>
                                </li>
                            @endif


                            <li class="nav-item">
                                <a class="nav-link  " href="{{ route('admin-models_category-index') }}"
                                    aria-controls="sidebarmodels_category">
                                    <span>@lang('translation.features')</span>
                                </a>
                            </li>

                            <!-- #region -->
                        </ul>
                    </div>
                </li>


 @if (Auth::guard('admin')->user()->sectionCheck('testimonials'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-testimonials-index') }}"
                            aria-controls="sidebarblogs">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.dentistry')</span>
                        </a>
                    </li>
                @endif 
                <li class="nav-item">
                    <a class="nav-link menu-link" href="#models1" data-bs-toggle="collapse" role="button"
                        aria-expanded="false" aria-controls="models1">
                        <i class="las la-cog"></i> <span data-key="t-General_Settings"> @lang('translation.invisalign')</span>
                    </a>
                    <div class="collapse menu-dropdown" id="models1">
                        <ul class="nav nav-sm flex-column">


                            <li class="nav-item">
                                <a class="nav-link  " href="{{ route('admin-about_points-index') }}"
                                    aria-controls="sidebarportfolio">
                                    <i class="las la-tachometer-alt"></i> <span>@lang('translation.about_points')</span>
                                </a>
                            </li>
                            @if (Auth::guard('admin')->user()->sectionCheck('after_befores'))
                                <li class="nav-item">
                                    <a class="nav-link  " href="{{ route('admin-after_befores-index') }}"
                                        aria-controls="sidebarafter_befores">
                                        <i class="las la-tachometer-alt"></i> <span>@lang('translation.after_befores')</span>
                                    </a>
                                </li>
                            @endif
                            <!-- #region -->
                        </ul>
                    </div>
                </li>


                <li class="nav-item">
                    <a class="nav-link menu-link" href="#models2" data-bs-toggle="collapse" role="button"
                        aria-expanded="false" aria-controls="models2">
                        <i class="las la-cog"></i> <span data-key="t-General_Settings"> @lang('translation.dental_implants')</span>
                    </a>
                    <div class="collapse menu-dropdown" id="models2">
                        <ul class="nav nav-sm flex-column">


                            @if (Auth::guard('admin')->user()->sectionCheck('partners'))
                                <li class="nav-item">
                                    <a class="nav-link  " href="{{ route('admin-partners-index') }}"
                                        aria-controls="sidebarpartners">
                                        <i class="las la-tachometer-alt"></i> <span>@lang('translation.gallery')</span>
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link menu-link" href="#models3" data-bs-toggle="collapse" role="button"
                        aria-expanded="false" aria-controls="models3">
                        <i class="las la-cog"></i> <span data-key="t-General_Settings"> @lang('translation.veneers')</span>
                    </a>
                    <div class="collapse menu-dropdown" id="models3">
                        <ul class="nav nav-sm flex-column">

 

                @if (Auth::guard('admin')->user()->sectionCheck('models'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-models-index') }}" aria-controls="sidebarblogs">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.after_and_before')</span>
                        </a>
                    </li>
                @endif
 
                @if (Auth::guard('admin')->user()->sectionCheck('processes'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-processes-index') }}"
                            aria-controls="sidebarblogs">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.small_changes')</span>
                        </a>
                    </li>
                @endif
                        </ul>
                    </div>
                </li>


                {{-- <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-ps-our_team') }}" aria-controls="sidebarour_team">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.our_team_section')</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-ps-after_before') }}" aria-controls="sidebarportfolio">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.after_before')</span>
                        </a>
                    </li> --}}
 
                @if (Auth::guard('admin')->user()->sectionCheck('doctors'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-doctors-index') }}"
                            aria-controls="sidebarblogs">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.doctors')</span>
                        </a>
                    </li>
                @endif
                {{-- @if (Auth::guard('admin')->user()->sectionCheck('testimonials'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-testimonials-index') }}"
                            aria-controls="sidebarblogs">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.testimonials')</span>
                        </a>
                    </li>
                @endif --}}

                {{--  


                @if (Auth::guard('admin')->user()->sectionCheck('media'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-media-index') }}" aria-controls="sidebarmedia">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.gallery')</span>
                        </a>
                    </li>
                @endif
--}}
                @if (Auth::guard('admin')->user()->sectionCheck('locations'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-locations-index') }}"
                            aria-controls="sidebarlocations">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.locations')</span>
                        </a>
                    </li>
                @endif
                {{-- --}}
                {{-- --}}

             {{--   @if (Auth::guard('admin')->user()->sectionCheck('certificates'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-certificates-index') }}"
                            aria-controls="sidebarcertificates">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.certificates')</span>
                        </a>
                    </li>
                @endif  --}}
                {{--       @if (Auth::guard('admin')->user()->sectionCheck('services'))
         
                     <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-services-index') }}"
                            aria-controls="sidebarservices">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.services')</span>
                        </a>
                    </li>
                    @endif
 --}}
                @if (Auth::guard('admin')->user()->sectionCheck('services') ||
                        Auth::guard('admin')->user()->sectionCheck('categories') ||
                        Auth::guard('admin')->user()->sectionCheck('subcategories'))
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="#services" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="services">
                            <i class="las la-cog"></i> <span data-key="t-General_Settings"> @lang('translation.services')</span>
                        </a>
                        <div class="collapse menu-dropdown" id="services">
                            <ul class="nav nav-sm flex-column">
                                {{-- 
                                @if (Auth::guard('admin')->user()->sectionCheck('categories'))
                                    <li class="nav-item">
                                        <a class="nav-link  " href="{{ route('admin-categories-index') }}"
                                            aria-controls="sidebar_category">
                                            <span>@lang('translation.categories')</span>
                                        </a>
                                    </li>
                                @endif
                                @if (Auth::guard('admin')->user()->sectionCheck('subcategories'))
                                    <li class="nav-item">
                                        <a class="nav-link  " href="{{ route('admin-subcategories-index') }}"
                                            aria-controls="sidebar_subcategories">
                                            <span>@lang('translation.subcategories')</span>
                                        </a>
                                    </li>
                                @endif --}}
                                @if (Auth::guard('admin')->user()->sectionCheck('services'))
                                    <li class="nav-item">
                                        <a class="nav-link  " href="{{ route('admin-services-index') }}"
                                            aria-controls="sidebarservices">
                                            <span>@lang('translation.services')</span>
                                        </a>
                                    </li>
                                @endif
                            </ul>
                        </div>
                    </li>

                @endif
                {{-- @if (Auth::guard('admin')->user()->sectionCheck('models'))
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="#models" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="models">
                            <i class="las la-cog"></i> <span data-key="t-General_Settings"> @lang('translation.about_us_sections')</span>
                        </a>
                        <div class="collapse menu-dropdown" id="models">
                            <ul class="nav nav-sm flex-column">

 
                                <li class="nav-item">
                                    <a class="nav-link  " href="{{ route('admin-models-index') }}"
                                        aria-controls="sidebarmodels">
                                        <span>@lang('translation.home_about_section')</span>
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </li> <!-- end Dashboard Menu -->
                @endif --}}


                @if (Auth::guard('admin')->user()->sectionCheck('blogs'))
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-blogs-index') }}" aria-controls="sidebarblogs">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.blogs')</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link  " href="{{ route('admin-faqs-index') }}" aria-controls="sidebarfaqs">
                            <i class="las la-tachometer-alt"></i> <span>@lang('translation.faqs')</span>
                        </a>
                    </li>
                @endif

                @if (Auth::guard('admin')->user()->sectionCheck('general_settings'))
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="#general" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="general">
                            <i class="las la-cog"></i> <span data-key="t-General_Settings"> @lang('translation.settings')</span>
                        </a>
                        <div class="collapse menu-dropdown" id="general">
                            <ul class="nav nav-sm flex-column">

                                <li class="nav-item">
                                    <a href="{{ route('admin-gs-logo') }}" class="nav-link" data-key="t-Logo">
                                        @lang('translation.logo')
                                    </a>
                                </li>
                                {{-- --}}<li class="nav-item">
                                    <a href="{{ route('admin-gs-home_video') }}" class="nav-link"
                                        data-key="t-home_video">
                                        @lang('translation.home_video')
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="{{ route('admin-gs-contents') }}" class="nav-link"
                                        data-key="t-Website_Contents"> @lang('translation.content') </a>
                                </li>

                                <li class="nav-item">
                                    <a href="{{ route('admin-gs-contact_messages') }}" class="nav-link"
                                        data-key="t-contact_messages"> @lang('translation.contact_messages') </a>
                                </li>

                                <li class="nav-item">
                                    <a href="{{ route('admin-gs-subscriptions') }}" class="nav-link"
                                        data-key="t-Manage_Roles"> @lang('translation.subscriptions') </a>
                                </li>

                                @if (Auth::guard('admin')->user()->sectionCheck('social_settings'))
                                    <li class="nav-item">
                                        <a href="{{ route('admin-social-index') }}" class="nav-link"
                                            data-key="t-Manage_Roles"> @lang('translation.social_settings') </a>
                                    </li>
                                @endif

                                @if (Auth::guard('admin')->user()->sectionCheck('super'))
                                    <li class="nav-item">
                                        <a href="{{ route('admin-role-index') }}" class="nav-link"
                                            data-key="t-Manage_Roles"> @lang('translation.role_mangment') </a>
                                    </li>
                                @endif



                                @if (Auth::guard('admin')->user()->sectionCheck('manage_staffs'))
                                    <li class="nav-item">
                                        <a href="{{ route('admin-staff-index') }}" class="nav-link"
                                            data-key="t-Manage_Stauff"> @lang('translation.staff_mangment') </a>
                                    </li>
                                @endif
                                @if (Auth::guard('admin')->user()->sectionCheck('language'))
                                    <li class="nav-item">
                                        <a href="{{ route('admin-flang-index') }}" class="nav-link"
                                            data-key="t-Manage_Roles"> @lang('translation.language') </a>
                                    </li>
                                @endif

                            </ul>
                        </div>
                    </li> <!-- end Dashboard Menu -->
                @endif
                @if (Auth::guard('admin')->user()->sectionCheck('super'))
                    <li class="nav-item">
                        <a class="nav-link menu-link" href="{{ route('admin-cache-clear') }}">
                            <i class="las la-flask"></i> <span data-key="t-Clear_Cache"> @lang('translation.cache_clear') </span>
                        </a>
                    </li>
                @endif
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
    <div class="sidebar-background"></div>
</div>
<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>
